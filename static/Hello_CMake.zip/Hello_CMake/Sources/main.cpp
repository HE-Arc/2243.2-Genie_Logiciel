#include "Hello/hello.h"
#include "World/world.h"

#include <iostream>

int main()
{
	Hello hello;
	World world;

	hello.Run();
	world.Run();

	return 0;
}
