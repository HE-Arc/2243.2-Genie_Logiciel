#pragma once

class Hello
{
public:

	Hello() = default;
	virtual ~Hello() = default;
	Hello(const Hello &hello) = delete;
	Hello &operator=(const Hello &hello) = delete;

	void Run();
};
