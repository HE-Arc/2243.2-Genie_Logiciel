// STD
#include <iostream>
// LOCAL INCLUDES
#include "hello.h"

void Hello::Run()
{
	std::cout << "Hello";
}
