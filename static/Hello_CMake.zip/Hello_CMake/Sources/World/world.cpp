// STD
#include <iostream>
// LOCAL INCLUDES
#include "world.h"

void World::Run()
{
	auto f = 12.0;
	std::cout << " World!!!" << std::endl;
}
