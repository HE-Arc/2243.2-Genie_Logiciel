#pragma once

class World
{
public:

	World() = default;
	virtual ~World() = default;
	World(const World &world) = delete;
	World &operator=(const World &world) = delete;

	void Run();
};
